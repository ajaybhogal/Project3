package assignment22;

import java.util.Scanner;

public class Assignment22 {

    public static void printHeader() {
        System.out.println("***********************");
        System.out.println("The Power Function");
        System.out.println("***********************");
        
    }

    public static int askNumber() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number: ");
        int number = sc.nextInt();

        return number;

    }

    public static int askPower() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the power: ");
        int power = sc.nextInt();
        return power;
    }

    public static int powerCalc(int x, int y) {
        int result = 1;

        for (int i = 0; i < y; i++) {
            result = result*x;
        }
       return result;
    }

    public static void main(String[] args) {
        int x, y;
        printHeader();
        x = askNumber();
        y = askPower();
        System.out.println("The Result is: " + powerCalc(x, y));
        printFooter();
        

    }

    public static void printFooter() {
        System.out.println("End of the program");

    }

}

